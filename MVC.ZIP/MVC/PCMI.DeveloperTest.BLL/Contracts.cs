﻿using System;
using System.Collections.Generic;
using System.Linq;
using PCMI.DeveloperTest.Model;

namespace PCMI.DeveloperTest.BLL
{
    public class Contracts : IContracts
    {
        private IEnumerable<Contract> GenerateData()
        {
            return new List<Contract>
            {
                new Contract(1, "CL10008", "Cole", "Baltz", Status.Inactive, 100.23m),
                new Contract(2, "CL10001", "John", "Doe", Status.Active, 200.4m),
                new Contract(3, "CL10005", "Cleo", "Rowse", Status.Active, 150.5m),
                new Contract(4, "CL10003", "John", "Engell", Status.Active, 235.0m),
                new Contract(5, "CL10004", "Kelly", "Dickson", Status.Active, 78.9m),
                new Contract(6, "CL10009", "Angeline", "Carper", Status.Active, 101.01m),
                new Contract(7, "CL10006", "Adel", "Marschall", Status.Inactive, 827.12m),
                new Contract(8, "CL10002", "Tom", "Smith", Status.Inactive, 543.56m),
                new Contract(9, "CL10007", "Klara", "Larkin", Status.Active, 10.99m)
            };
        }

        public IEnumerable<Contract> GetAllContracts()
        {
            return GenerateData();
        }
        public IEnumerable<Contract> GetActiveContracts()
        {
            return GenerateData().Where(c => c.Status == Status.Active).OrderBy(c => c.Number);
        }


        public void ActivateContract(Contract contract)
        {
            contract.Status = Status.Active;
        }
    }
}
