﻿using System.Collections.Generic;
using PCMI.DeveloperTest.Model;

namespace PCMI.DeveloperTest.BLL
{
    public interface IContracts
    {
        IEnumerable<Contract> GetAllContracts();
        IEnumerable<Contract> GetActiveContracts();
        void ActivateContract(Contract contract);
    }
}