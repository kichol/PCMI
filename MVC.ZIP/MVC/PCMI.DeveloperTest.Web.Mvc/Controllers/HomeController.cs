using System.Web.Mvc;
using PCMI.DeveloperTest.BLL;

namespace PCMI.DeveloperTest.Web.Mvc.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var contracts = Factory.GetContracts();
            return View(contracts.GetActiveContracts());
        }

        public ActionResult GridViewPartialView()
        {
            var contracts = Factory.GetContracts();
                
            return PartialView("GridViewPartialView", contracts.GetActiveContracts());
        }
    }
}